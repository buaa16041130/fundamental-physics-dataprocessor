﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dataprocessor1._0
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double xbar;
            double xa;
            switch (int.Parse(this.textBox21.Text))
            {
                case 1:
                        MessageBox.Show("输入有误，请重新输入", "结果");
                    break;
                case 2:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text)) /2;
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 3:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text))/3;
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 4:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text)) / 4;
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 5:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text)) / 5;
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 6:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 7:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 8:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 9:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                ) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 10:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 11:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 12:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                ) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                           )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 13:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 14:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                           )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 15:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 ) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 16:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 + double.Parse(this.textBox16.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox16.Text) - xbar), 2)
                           )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 17:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 + double.Parse(this.textBox16.Text) + double.Parse(this.textBox17.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox16.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox17.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 18:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 + double.Parse(this.textBox16.Text) + double.Parse(this.textBox17.Text) + double.Parse(this.textBox18.Text)
                 ) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox16.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox17.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox18.Text) - xbar), 2)
                           )
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 19:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 + double.Parse(this.textBox16.Text) + double.Parse(this.textBox17.Text) + double.Parse(this.textBox18.Text)
                 + double.Parse(this.textBox19.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox16.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox17.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox18.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox19.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                case 20:
                    {
                        xbar = (double.Parse(this.textBox1.Text) + double.Parse(this.textBox2.Text) + double.Parse(this.textBox3.Text)
                 + double.Parse(this.textBox4.Text) + double.Parse(this.textBox5.Text) + double.Parse(this.textBox6.Text)
                 + double.Parse(this.textBox7.Text) + double.Parse(this.textBox8.Text) + double.Parse(this.textBox9.Text)
                 + double.Parse(this.textBox10.Text) + double.Parse(this.textBox11.Text) + double.Parse(this.textBox12.Text)
                 + double.Parse(this.textBox13.Text) + double.Parse(this.textBox14.Text) + double.Parse(this.textBox15.Text)
                 + double.Parse(this.textBox16.Text) + double.Parse(this.textBox17.Text) + double.Parse(this.textBox18.Text)
                 + double.Parse(this.textBox19.Text) + double.Parse(this.textBox20.Text)) / int.Parse(this.textBox21.Text);
                        xa = Math.Sqrt((Math.Pow((double.Parse(this.textBox1.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox2.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox3.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox4.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox5.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox6.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox7.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox8.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox9.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox10.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox11.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox12.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox13.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox14.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox15.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox16.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox17.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox18.Text) - xbar), 2)
                            + Math.Pow((double.Parse(this.textBox19.Text) - xbar), 2) + Math.Pow((double.Parse(this.textBox20.Text) - xbar), 2))
                             / (int.Parse(this.textBox21.Text) * (int.Parse(this.textBox21.Text) - 1)));
                        MessageBox.Show("A类不确定度的值为：" + xa, "结果");
                    }
                    break;
                default:
                    {
                        MessageBox.Show("输入有误，请重新输入", "警告");
                    }
                    break;
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Form1 f01 = new Form1();
            f01.Show();
        }
    }
}
